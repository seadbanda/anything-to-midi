
//----------------------- Global Declarations -------------------------------





// ************************ Global Functions ********************************

// ------------------------- RTC --------------------------------------------

extern u8 Set_Time( u8* TimeLow, u8* TimeHigh );
extern u8 Get_Time( u8* TimeLow, u8* TimeHigh );








// ************************ Global Variables ********************************


extern u32    g_u32_CurrentTimeLow;
extern u16    g_u16_CurrentTimeHigh;