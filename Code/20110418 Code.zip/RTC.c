/* -----------------------------------------------
Implements the RTC procedures 

Communication with the RTC is with SPI port 1

Pins 
CS    -   Pin 20  - PA4
SCK   -   Pin 21  - PA5
MISO  -   Pin 22  - PA6
MOSI  -   Pin 23  - PA7

--------------------------------------------------*/

//#include "iostm32f10xxB.h"
#include "globaldefinitions.h"
#include "spi.h"
#include "GlobalDeclarations.h"
#include "stm32f10x_spi.h"
#include "stm32f10x_spi.c"



// RTC specific Definitions

// Registers

#define RTC_CONTROL_1   0x00
#define RTC_CONTROL_2   0x01
#define RTC_Seconds     0x02
#define RTC_Minutes     0x03
#define RTC_Hours       0x04
#define RTC_Days        0x05
#define RTC_Months      0x07
#define RTC_Years       0x08
#define RTC_Minute_Alarm  0x09
#define RTC_Hour_Alarm    0x0A
#define RTC_Day_Alarm     0x0B
#define RTC_Offset        0x0D
#define RTC_CLKOUT        0x0E
#define RTC_Countdown     0x0F

// Bits

// CONTROL_1
#define RTC_C1_TEST   BIT7
#define RTC_C1_SR6    BIT6
#define RTC_C1_STOP   BIT5
#define RTC_C1_SR4    BIT4
#define RTC_C1_SR3    BIT3
#define RTC_C1_12_24  BIT2
#define RTC_C1_CIE    BIT1

// CONTROL_2
#define RTC_C2_MI      BIT7
#define RTC_C2_SI      BIT6
#define RTC_C2_MSF     BIT5
#define RTC_C2_TI_TP   BIT4
#define RTC_C2_AF      BIT3
#define RTC_C2_TF      BIT2
#define RTC_C2_AIE     BIT1
#define RTC_C2_TIE     BIT0



SPI_InitTypeDef   SPI_InitStructure;


/*-----------------------------------------------------------------------------

     config_SPI()
    
    Sets up the SPI port to communicate with the RTC, enables the RTC CS pin
    
    No arguments, returns OK or NOK
    
------------------------------------------------------------------------------*/

u8   Config_SPI(void){
  
  
//  RCC_APB2ENR = RCC_APB2ENR | BIT2 ;  // enable Port A
//  
//  GPIOA_CRL = 0x11111111;              // set port to output push pull
//  GPIOA_CRH = 0x11111111;                          
//
//
//  GPIOA_BSRR = 0xFFFF0000;  
//  GPIOA_BSRR = BIT4 ;
//  GPIOA_BSRR = BIT5 ;
//  GPIOA_BSRR = BIT6 ;
//  GPIOA_BSRR = BIT7 ;
//  
//  GPIOA_BSRR = 0xFFFF0000 ;
//  
//  
//  RCC_APB2ENR = RCC_APB2ENR | BIT12 ;  // enable the clock for the I2C 
//
//  SPI1_CR1 =  BR2 | MSTR | SSM;        // Baud Rate Fpclk/32 , Master Configuration, SPI Enabled, no hardware CRC, 
//  SPI1_CR1 =  BR2 | MSTR | SPE | SSM;       // 8-bit frame size, positive clock polarity, MSB first, Software slave management
//  
//  SPI1_CR2 = 0x00;                     // interrupts all disabled SS output disabled

  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4;
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_LSB;
  SPI_InitStructure.SPI_CRCPolynomial = 7;
  SPI_Init(SPIy, &SPI_InitStructure); 
  
  
  
  return OK;  
}




/*-----------------------------------------------------------------------------

     Write_SPI
    
    Writes up to 6 bytes to the defined Address
    
    arguments  
      address
      length of the message
      data (stored in a 1d array of length 6)
    
    Returns OK or NOK
    

------------------------------------------------------------------------------*/

u8 Write_SPI(u8 _RegAddress, u8 _MessageLength, u8 *pu8_Data)
{
             
  while(!(SPI1_SR && TXE));       // check the TXE flag, wait until TX buffer is empty  
        
  SPI1_DR  = _RegAddress + 0x90;       // transmit the write command and the address
      
  for(u8 _i = 0; _i < _MessageLength; _i++)    // do this loop depending on MessageLength
  {
    
    while(!(SPI1_SR && TXE));       // check the TXE flag, wait until TX buffer is empty
    
    SPI1_DR = *((u8*)pu8_Data + _i);

  }
          
  return OK;
}
          

/*-----------------------------------------------------------------------------      

      Read_SPI
      
    Read up to 6 bits from the RTC
    
    arguments          
      address        
      length of the message      
      the pointer to an array to store the data in
              
    Returns OK or NOK
          
------------------------------------------------------------------------------*/
          
u8 Read_SPI(u8 _RegAddress, u8 _MessageLength, u8* pu8_Data){
  
  Config_SPI();                   // configure the SPI port
  
  while(!(SPI1_SR && TXE));       // check the TXE flag, wait until TX buffer is empty   
  
  SPI1_DR  = _RegAddress + 0x10;        // transmit the read command
  
  for(u8 _i = 0; _i < _MessageLength; _i++)    // do this loop depending on MessageLength
  {
    
    while(!(SPI1_SR && RXNE));       // check the RXNE flag, wait until RX buffer is not empty
    
    *((u8*)pu8_Data + _i) = SPI1_DR;               // read out the data

  }
  
  return OK;
  
}

/*-----------------------------------------------------------------------------

    Set_Time
    
    Sets the Time in the RTC
    
    arguments:
      Second, Minute, Hour, Day, Month, Year
    
    Returns OK or NOK

------------------------------------------------------------------------------*/

extern u8 Set_Time( u8* pu8_TimeLow, u8* pu8_TimeHigh )
{
  
  Config_SPI();                                           // set up the SPI port
    
  Write_SPI(RTC_Seconds, 0x04, (u8*)&pu8_TimeLow);        // Write the second, minute, hour and day
  Write_SPI(RTC_Months, 0x02, (u8*)&pu8_TimeHigh);        // Write the Month and Year
  
  return OK;  
  
}


/*-----------------------------------------------------------------------------

    Get_Time
    
    Gets the Time in the RTC
    
    arguments:
      Second, Minute, Hour, Day, Month, Year
    
    Returns OK or NOK

------------------------------------------------------------------------------*/

extern u8 Get_Time( u8* pu8_TimeLow, u8* pu8_TimeHigh )
{
  
  Config_SPI();                                           // set up the SPI port
  
  Read_SPI(RTC_Seconds, 0x04, (u8*)&pu8_TimeLow );        // Read the second, minute, hour and day
  Read_SPI(RTC_Months, 0x02, (u8*)&pu8_TimeHigh );        // Read the Month and Year
  
  return OK;  
  
}