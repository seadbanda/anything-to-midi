
//#include "stm32f10x.h"
#include "iostm32f10xxB.h"
#include "globaldefinitions.h"
#include "GlobalDeclarations.h"


u32    g_u32_CurrentTimeLow;
u16    g_u16_CurrentTimeHigh;

int main()
{
  

  RCC_APB2ENR = RCC_APB2ENR | BIT4 ;  // enable the clock for Port C   
  
  GPIOC_CRL = 0x11111111;              // set port to output push pull
  GPIOC_CRH = 0x11111111;                          


  GPIOC_BSRR = 0xF0000000;  
  GPIOC_BSRR = BIT15 ;
  
  g_u32_CurrentTimeLow =  0x1203050D;        // Array with the Current Time stored in it. [ days, hours, minutes, seconds ]
  g_u16_CurrentTimeHigh = 0x0A04;       // Array with the Current Time stored in it/ [ years, months ]
  
  Set_Time((u8*)&g_u32_CurrentTimeLow, (u8*)&g_u16_CurrentTimeHigh);
  GPIOC_BSRR = BIT14;
  Get_Time((u8*)&g_u32_CurrentTimeLow, (u8*)&g_u16_CurrentTimeHigh);
  GPIOC_BSRR = BIT13;
    
  
  while(1);
  
  return 0;
}

