
#include  "globaldefinitions.h"

  #define SPIy                   SPI1
  #define SPIy_CLK               RCC_APB2Periph_SPI1
  #define SPIy_GPIO              GPIOA
  #define SPIy_GPIO_CLK          RCC_APB2Periph_GPIOA  
  #define SPIy_PIN_SCK           GPIO_Pin_5
  #define SPIy_PIN_MISO          GPIO_Pin_6
  #define SPIy_PIN_MOSI          GPIO_Pin_7